import { registerDecorator, ValidatorConstraint } from "class-validator";
import { __decorate } from "../../../helpers/decorate";

export function IsMatchThenDelete(property: any, validationOptions: any) {
  return (object: { constructor: any }, propertyName: any) => {
    registerDecorator({
      target: object.constructor,
      propertyName,
      options: validationOptions,
      constraints: [property],
      validator: IsMatchThenDeleteConstraint,
    });
  };
}

let IsMatchThenDeleteConstraint = class IsMatchThenDeleteConstraint {
  validate(
    value: any,
    args: { constraints: [any]; object: { [x: string]: any } }
  ) {
    const [relatedPropertyName] = args.constraints;
    const relatedValue = args.object[relatedPropertyName];
    const result = value === relatedValue;
    delete args.object[relatedPropertyName];
    return result;
  }
};
IsMatchThenDeleteConstraint = __decorate(
  [ValidatorConstraint({ name: "IsMatchThenDelete" })],
  IsMatchThenDeleteConstraint
);
