export let StandAloneKeys: { about: any; mission: any; vision: any };
(function (StandAloneKeys) {
  StandAloneKeys["about"] = "about";
  StandAloneKeys["mission"] = "mission";
  StandAloneKeys["vision"] = "vision";
})((StandAloneKeys = exports.StandAloneKeys || (exports.StandAloneKeys = {})));
